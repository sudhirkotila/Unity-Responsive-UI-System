using System.Collections.Generic;
using UnityEngine;

public class ResponsiveByPosition : ResponsiveParentClass
{
    public List<ResponsiveElement<Vector3>> positionsForRatio;

    Vector3 defaulPosition;

    protected override void Awake()
    {
        defaulPosition = transform.localPosition;
        base.Awake();
    }

    protected override void UpdateUI()
    {
        ResponsiveElement<Vector3> curPos = positionsForRatio.Find((x) => x.screenRatio == ResponsiveController.screenRatio);
        if (curPos != null)
            transform.localPosition = curPos.element;
        else
            transform.localPosition = defaulPosition;
    }
}
