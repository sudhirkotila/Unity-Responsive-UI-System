using System;
using UnityEngine;

public abstract class ResponsiveParentClass : MonoBehaviour
{
    protected virtual void Awake()
    {
        UpdateUI();
        ResponsiveController.onChangeScreenResolution += UpdateUI;
    }

    protected abstract void UpdateUI();

    protected virtual void OnDestroy()
    {
        ResponsiveController.onChangeScreenResolution -= UpdateUI;
    }
}

[Serializable]
public class ResponsiveElement<T>
{
    public ScreenRatio screenRatio;

    public T element;
}