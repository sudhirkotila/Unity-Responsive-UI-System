using UnityEngine;
using System.Collections.Generic;

public class ResponsiveByScale : ResponsiveParentClass
{
    public bool isPortraitCheck = true;
    public bool isLandcapeCheck = true;
    public List<ResponsiveElement<Vector3>> scalesForRatio;

    Vector3 defaulScale;

    protected override void Awake()
    {
        defaulScale = transform.localScale;
        base.Awake();
    }

    protected override void UpdateUI()
    {
        if ((Screen.width < Screen.height && isPortraitCheck) || (Screen.width > Screen.height && isLandcapeCheck))
        {
            ResponsiveElement<Vector3> curScale = scalesForRatio.Find((x) => x.screenRatio == ResponsiveController.screenRatio);
            if (curScale != null)
                transform.localScale = curScale.element;
            else
                transform.localScale = defaulScale;
        }
    }

    internal void ForceUpdateUI()
    {
        UpdateUI();
    }
}