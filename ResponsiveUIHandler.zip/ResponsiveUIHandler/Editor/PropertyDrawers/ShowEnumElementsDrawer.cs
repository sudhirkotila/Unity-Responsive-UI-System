﻿#region Using
using UnityEngine;
using UnityEditor;
using System;
#endregion

/// <Summary> 
/// Enum Drawer, To show Enum Names in list of array instead of "element X" 
/// in Insepctor window.
[CustomPropertyDrawer(typeof(ShowEnumElementsAttribute))]
public class ShowEnumElementsDrawer : PropertyDrawer
{
    /// <Summary> 
    /// Overridden to change from "element X" to "[Enum Member Name]"
    /// </Summary>
    public override void OnGUI(Rect rect, SerializedProperty property, GUIContent label)
    {
        try
        {
            string[] splitedPath = property.propertyPath.Split('[', ']');
            int indexOfArray = int.Parse(splitedPath[splitedPath.Length - 2]);
            Type enumType = (attribute as ShowEnumElementsAttribute).enumType;
            string elementName = enumType.GetEnumName(indexOfArray);
            if (string.IsNullOrEmpty(elementName))
                EditorGUI.PropertyField(rect, property, label);
            else
                EditorGUI.PropertyField(rect, property, new GUIContent(elementName));
        }
        catch
        {
            EditorGUI.PropertyField(rect, property, label);
        }
    }
}