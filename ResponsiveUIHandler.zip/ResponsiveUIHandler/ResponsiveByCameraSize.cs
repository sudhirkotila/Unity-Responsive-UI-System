using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(Camera))]
public class ResponsiveByCameraSize : ResponsiveParentClass
{
    public List<ResponsiveElement<float>> sizesForRatio;

    Camera attachedCamera;

    float defaulCameraSize;

    protected override void Awake()
    {
        attachedCamera = GetComponent<Camera>();
        defaulCameraSize = attachedCamera.orthographicSize;

#if UNITY_EDITOR
        if (!attachedCamera.orthographic)
            Debug.LogWarning("This script is useless as camera's projection is not set as orthographic");
#endif

        base.Awake();
    }

    protected override void UpdateUI()
    {
        ResponsiveElement<float> curSize = sizesForRatio.Find((x) => x.screenRatio == ResponsiveController.screenRatio);
        if (curSize != null)
            attachedCamera.orthographicSize = curSize.element;
        else
            attachedCamera.orthographicSize = defaulCameraSize;
    }
}
