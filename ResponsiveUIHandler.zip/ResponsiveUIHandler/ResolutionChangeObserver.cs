using UnityEngine;

public class ResolutionChangeObserver : MonoBehaviour
{
    public ScreenRatio curScreenRatio;

    Vector2Int lastScreenSize;

    void Start()
    {
        lastScreenSize = new Vector2Int(Screen.width, Screen.height);
        curScreenRatio = ResponsiveController.screenRatio;
    }

    void Update()
    {
        if (lastScreenSize.x != Screen.width || lastScreenSize.y != Screen.height)
        {
            // Debug.Log("Changed Screen Resolution from " + lastScreenSize.x + "x" + lastScreenSize.y 
            //     + " to " + Screen.width + "x" + Screen.height);
            ScreenRatio lastRatio = ResponsiveController.screenRatio;
            ResponsiveController.CheckScreenRatio();

            curScreenRatio = ResponsiveController.screenRatio;
            lastScreenSize.x = Screen.width;
            lastScreenSize.y = Screen.height;

            if (lastRatio != curScreenRatio)
            {
                Debug.Log("Changed Screen Ratio");
                ResponsiveController.onChangeScreenResolution?.Invoke();
                lastRatio = ResponsiveController.screenRatio;
            }
        }
    }
}