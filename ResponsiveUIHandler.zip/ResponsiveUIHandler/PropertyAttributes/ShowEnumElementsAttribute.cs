﻿    #region Using
    using System;
    using UnityEngine;
    #endregion

    /// <Summary> 
    /// Token Color Array Attribute, To show Token Color Names in list of array instead of "element X" 
    /// in Insepctor window.
    /// </Summary>
    [AttributeUsage(AttributeTargets.Field, Inherited = true, AllowMultiple = true)]
    public class ShowEnumElementsAttribute : PropertyAttribute
    {
        public Type enumType;
        
        public ShowEnumElementsAttribute(Type enumType)
        {
            this.enumType = enumType;
        }
    }