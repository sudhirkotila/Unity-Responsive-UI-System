﻿using UnityEngine;

public class AdjustCameraSize : MonoBehaviour
{
    public Renderer referenceObj;
    public float refSize;
    public float minOrthographicSize = 0;


    void Awake()
    {
        UpdateUI();
    }

    private void OnEnable()
    {
        // UEventSystem.OnScreenOrientation += UpdateUI;
        ResponsiveController.onChangeScreenResolution += UpdateUI;
    }

    private void OnDisable()
    {
        // UEventSystem.OnScreenOrientation -= UpdateUI;
        ResponsiveController.onChangeScreenResolution -= UpdateUI;
    }

    public void UpdateUI()
    {
        float size = referenceObj != null ? referenceObj.bounds.size.x : refSize;
        size = size * Screen.height / Screen.width * 0.45f;
        if (size < minOrthographicSize)
            size = minOrthographicSize;
        GetComponent<Camera>().orthographicSize = size;
    }
}
