using System;
using UnityEngine;

public class ResponsiveController : MonoBehaviour
{
    #region Variables
    static int ratioAsInt = 17;
    public static ScreenRatio screenRatio = ScreenRatio.Ratio16x9;

    public const int TOTAL_DIFFERNT_SCREEN_RATIO = 4;

    //Disable ads for all tablet devices
    public static bool DoesResolutionSupportAds
    {
        get
        {
            return ratioAsInt >= 15;
        }
    }

    public static Action onChangeScreenResolution;

    private ResolutionChangeObserver resolutionChangeObserver = null;
    #endregion


    void Awake()
    {
        CheckScreenRatio();
    }

    void Start()
    {
        // CheckForMultipleResolutionDevice();

#if UNITY_EDITOR
        CreateResolutionChangeObserver();
#endif
    }

    void OnEnable()
    {
        // UEventSystem.OnServerConfigDataLoad += OnServerConfigDataLoad;
    }

    void OnDisable()
    {
        // UEventSystem.OnServerConfigDataLoad -= OnServerConfigDataLoad;
    }

    // private void OnServerConfigDataLoad(ConfigType _configType)
    // {
    //     if (_configType == ConfigType.MultipleResolutionDevices)
    //     {
    //         CheckForMultipleResolutionDevice();
    //     }
    // }

    // void CheckForMultipleResolutionDevice()
    // {
    //     MultipleResolutionDevices multiple_resolution_devices = APIServerConfig.instance.serverConfigData.multiple_resolution_devices;

    //     if (multiple_resolution_devices == null || multiple_resolution_devices.ids == null)
    //         return;

    //     if (Array.IndexOf(multiple_resolution_devices.ids, SystemInfo.deviceModel) != -1)
    //     {
    //         //Fold Device Detected
    //         print("===== Fold Device Detected ===");
    //         GameConstants.isFoldDeviceDetected = true;
    //         CreateResolutionChangeObserver();
    //     }

    // }

    void CreateResolutionChangeObserver()
    {
        if (resolutionChangeObserver == null)
        {
            GameObject go = new GameObject("Resolution Change Observer");
            resolutionChangeObserver = go.AddComponent<ResolutionChangeObserver>();
            go.transform.SetParent(this.transform);
        }
    }

    public static void CheckScreenRatio()
    {
        float ratio = Screen.width > Screen.height ? (float)Screen.width / Screen.height : (float)Screen.height / Screen.width;
        ratioAsInt = (int)(ratio * 10);
        // Debug.Log("CheckScreenRatio " + ratioAsInt + " " + Screen.width + " X " + Screen.height);

        if (ratioAsInt >= 23)
        {
            screenRatio = ScreenRatio.Ratio21x9;
        }
        else if (ratioAsInt >= 20)
        {
            screenRatio = ScreenRatio.Ratio18x9;
        }
        else if (ratioAsInt >= 17)
        {
            screenRatio = ScreenRatio.Ratio16x9;
        }
        else if (ratioAsInt >= 15)
        {
            screenRatio = ScreenRatio.Ratio80x48;
        }
        else if (ratioAsInt >= 13)
        {
            screenRatio = ScreenRatio.Ratio4x3;
        }
        else if (ratioAsInt >= 10)
        {
            screenRatio = ScreenRatio.Ratio1x1;
        }

        else
        {
            Debug.Log("Unsupported Ratio : " + ratio);
            screenRatio = ScreenRatio.Ratio16x9;
        }

        Debug.Log("Screen Width : " + Screen.width + " Height : " + Screen.height);
        Debug.Log("Screen Ratio : " + ratio);
        Debug.Log("Screen Ratio as Int : " + ratioAsInt + " Type : " + screenRatio.ToString());
    }
}

public enum ScreenRatio
{
    Ratio21x9 = 0, //Fold-Portrait
    Ratio18x9 = 1,
    Ratio16x9 = 2,
    Ratio4x3 = 3, //Normal-Tab
    Ratio1x1 = 4,  //Fold-Tab,
    Ratio80x48 = 5
}